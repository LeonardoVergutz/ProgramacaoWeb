﻿using BlazorVendasAN.Data.Context;
using BlazorVendasAN.Entities;
using BlazorVendasAN.Service.Interface;
using Microsoft.EntityFrameworkCore;

namespace BlazorVendasAN.Service.Implementation
{
    public class FuncionarioService:IFuncionarioService
    {
        private readonly SQLServerContext _context;

        public FuncionarioService(SQLServerContext context)
        {
            _context = context;
        }

        public async Task AdicionarAsync(Funcionario funcionario)
        {
           _context.funcionarios.Add(funcionario);
            await _context.SaveChangesAsync();
        }

        public async Task AlterarAsync(Funcionario funcionario)
        {
            _context.funcionarios.Update(funcionario);
            await _context.SaveChangesAsync();
        }

        public async Task ExcluirAsync(int id)
        {
           var funcionario = await _context.funcionarios.FindAsync(id);
            if (funcionario != null)
            {
                _context.funcionarios.Remove(funcionario);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<Funcionario> ObterPorIdAsync(int id)
        {
            return await _context.funcionarios.FindAsync(id);
        }

        public async Task<Funcionario> ObterPorNomeAsync(string nome)
        {
            return await _context.funcionarios.FindAsync(nome);
        }

        public async Task<IEnumerable<Funcionario>> ObterTodosAsync()
        {
            return  await _context.funcionarios.ToListAsync();  
        }
    }
}
