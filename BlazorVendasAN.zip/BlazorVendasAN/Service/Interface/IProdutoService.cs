﻿using BlazorVendasAN.Entities;

namespace BlazorVendasAN.Service.Interface
{
    public interface IProdutoService
    {
       
        Task<Produto> ObterProdutoPorIdAsync(int id);
        Task<IEnumerable<Produto>> ObterTodosProdutosAsync();
        Task AdicionarAsync(Produto Produto);
        Task AlterarAsync(Produto Produto);
        Task ExcluirAsync(int id);
    }
}
